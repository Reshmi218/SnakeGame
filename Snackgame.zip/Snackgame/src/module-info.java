/**
 * 
 */
/**
 * @author Reshmi Sharma
 *
 */
module Snackgame {
}